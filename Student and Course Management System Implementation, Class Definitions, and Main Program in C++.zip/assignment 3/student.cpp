#include <iostream>
#include <string>
#include <cstring>
#include "student1.h"

using namespace std ;


void CStudent::setStudentName (string n)
{
    strcpy(student_name,n.c_str());
}

void CStudent::setStudentID (int n6)
{
    student_ID = n6;
}

void CStudent::setStudentEmail (string n2)
{
    strcpy (student_email_username,n2.c_str());
}

void CStudent::setStudentMajor (string n3)
{
    strcpy (student_major,n3.c_str());
}

void CStudent::setStudentGrades (float grade,int i)
{
    student_grades[i] = grade;
}

void CStudent::setStudentScore (float score)
{
    student_score=score;
}

void CStudent::setStudentEmailPassword (string n4)
{
    strcpy (student_email_password,n4.c_str());
}

// getter functions
string CStudent::getStudentName()
{
    return student_name;
}

int CStudent::getStudentID()
{
    return student_ID;
}

string CStudent::getStudentEmail()
{
    return student_email_username;
}

string CStudent::getStudentMajor()
{
    return student_major;
}

float CStudent::getStudentGrades(int i)
{
    return student_grades[i];
}

float CStudent::getStudentScore(){
    return student_score;
}

string CStudent::getStudentEmailPassword()
{
    return student_email_password;
}
CStudent::CStudent ()
{
    
}
void CStudent::registerStudent()
{
    string name;
    int id;
    string email;
    string major;
    float grades;
    string pass;
    cout << "Enter Your Full Name : ";
    getline(cin,name);
    getchar();
    cout << "Enter Your ID : ";
    cin >> id;
    cout << "Enter Your College Email : ";
    cin >> email;
    cout << "Enter Your Major : ";
    cin >> major;
    for (int i =0;i<5;i++){
    cout << "Enter the Grade number "<<i+1<<" : ";
    cin >> grades;
    setStudentGrades(grades,i);
    }
    cout << "Enter Your password : ";
    cin >> pass;
    setStudentName(name);
    setStudentID(id);
    setStudentEmail(email);
    setStudentMajor(major);
    setStudentEmailPassword(pass);
}
void CStudent::getStudentInfo ()
// prints the student’s data
{
    cout <<"Student Name : "<<getStudentName()<< "\n";
    cout <<"Student ID : "<< getStudentID()<< "\n";
    cout <<"Student Email : "<< getStudentEmail()<< "\n";
    cout <<"Student Major : "<< getStudentMajor()<< "\n";
    for (int i =0;i<5;i++){
    cout <<"Student grade number "<< i+1 << " : "<< getStudentGrades(i)<< "\n";
    }
    cout <<"Student score : "<< getStudentScore ()<< "\n";
    cout <<"Student email's password : "<< getStudentEmailPassword ()<< "\n";
}
float CStudent::claculateGPA()
//A public function that sums the items of student_grades[5] and divide the sum over 100 and assign the result to the student_score variable.
{
    float sum = 0;
    float calc;
    for (int i =0;i<5;i++)
    {
        sum += getStudentGrades(i);
    }
    calc = sum / 100;
    setStudentScore (calc);
}
void CCourse:: set_course_name(string nam)
{
    strcpy (course_name,nam.c_str());
}

void CCourse::set_course_code (string code)
{
    strcpy (course_code,code.c_str());
}

void CCourse::set_course_cost (float coast)
{
    course_cost = coast;
}

//getter functions
string CCourse::get_course_name ()
{
    return course_name;
}
string CCourse::get_course_code ()
{
    return course_code;
}
float CCourse::get_course_cost ()
{
    return course_cost;
}
void CCourse::AddCourse ()
// A public function that accepts values for the Course class members and store them.
{
    string name;
    string cod;
    float coste;
    
    cout <<"Enter course name : ";
    cin >> name;
    cout <<"Enter course code : ";
    cin >> cod;
    cout <<"Enter course coast : ";
    cin >> coste;
    set_course_name(name);
    set_course_code(cod);
    set_course_cost(coste);    
}
void CCourse::getCourseInfo ()
// A public function that prints the course’s details.
{
    cout <<"The course name : "<<get_course_name() << "\n";
    cout <<"The course code : "<<get_course_code() << "\n";
    cout <<"The course coast : "<<get_course_cost() << "\n";
}

