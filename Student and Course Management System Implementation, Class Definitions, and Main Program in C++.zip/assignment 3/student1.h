#include <iostream>
#include <string>
#include <cctype>

using namespace std ;

class CStudent
{
private:
char student_name [50];
int student_ID;
char student_email_username [10];
char student_major [10];
float student_grades [5];
float student_score;
char student_email_password [10];
public:
void setStudentName (string n);
void setStudentID (int n);
void setStudentEmail (string n);
void setStudentMajor (string n);
void setStudentGrades (float grade,int i);
void setStudentScore (float score);
void setStudentEmailPassword (string n);
string getStudentName ();
int getStudentID ();
string getStudentEmail ();
string getStudentMajor ();
float getStudentGrades (int i);
float getStudentScore ();
string getStudentEmailPassword ();
CStudent ();
void registerStudent () ;
void getStudentInfo () ;
float claculateGPA ();
};


class CCourse
{
private:
char course_name[20];
char course_code[5];
float course_cost;
public:
void set_course_name(string nam);
void set_course_code(string code);
void set_course_cost(float coast);
string get_course_name();
string get_course_code();
float get_course_cost();
void AddCourse ();
void getCourseInfo ();
};
