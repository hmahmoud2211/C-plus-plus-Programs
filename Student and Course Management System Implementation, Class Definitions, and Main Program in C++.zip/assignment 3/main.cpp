#include <iostream>
#include "student1.h"
#include <string>

using namespace std;

int main()
{
int  n_students;

    cout << "Enter the number of students: ";
    cin >> n_students;

    CStudent students[n_students];
 for (int i = 0; i < n_students; i++) {
        cout << "\nStudent #" << i + 1 << endl;
        students[i].registerStudent();
    }


    cout << "\nStudent Information:" << endl;
    for (int i = 0; i < n_students; i++) {
        cout << "\nStudent #" << i + 1 << endl;
        students[i].getStudentInfo();
    }

     int  num_of_cousres;

    cout << "Enter the number of courses: ";
    cin >> num_of_cousres ;

    CCourse course[num_of_cousres];
 for (int i = 0; i <  num_of_cousres; i++) {
        cout << "\ncourse >>>>" << i + 1 << endl;
        course[i].AddCourse();
    }


    cout << "\ncourse Information:" << endl;
    for (int i = 0; i < num_of_cousres ; i++) {
        cout << "\ncourse >>>>" << i + 1 << endl;
        course[i]. getCourseInfo();
    }

} 
