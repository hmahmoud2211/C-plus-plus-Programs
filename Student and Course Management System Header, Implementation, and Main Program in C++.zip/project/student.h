#ifndef STUDENT_H
#define STUDENT_H
#include<string>

using namespace std;
class student_cpp
{
private:

char student_name[50];//c1
int student_ID;// c2
char student_email_username[10];// c3
char student_major[10];// c4
float student_grades[5];// c5
float student_score;//c6
char student_email_password[10];//c7

public:
student_cpp();
// setter
void set_student_name(string n);
void set_student_ID(int n3);
void set_student_email(string n5);
void set_student_major(string n6);
void set_student_grades(float grade,int i);
void set_student_score(float score);
void set_student_email_password(string n2);
// getter
string get_student_name();
int get_student_ID();
string get_student_email();
string get_student_major();
float get_student_grades(int i);
float get_student_score();
string get_student_email_password();
// function
void regester ();
void getinfo();
void Calculate_GPA ();
// constructor

~ student_cpp();
};
#endif